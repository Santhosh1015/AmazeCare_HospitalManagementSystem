package com.hms.amazecare.controller;

public record ConversationAddResDto(
        Long conversationId
) {
}
