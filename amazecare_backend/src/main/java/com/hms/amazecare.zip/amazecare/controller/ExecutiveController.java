package com.hms.amazecare.controller;

import com.hms.amazecare.dto.request.ExecutiveDto;
import com.hms.amazecare.dto.response.ExecutiveResDto;
import com.hms.amazecare.service.ExecutiveService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class ExecutiveController {
    private final ExecutiveService executiveService;

    @PostMapping("/api/v1/executive/register")
    public ResponseEntity<ExecutiveResDto> registerExecutive(@Valid @RequestBody ExecutiveDto executiveDto,
                                                            Principal principal
    ){
        return ResponseEntity.ok()
                .body(executiveService.registerExecutive(executiveDto, principal.getName()));
    }

    @GetMapping("/api/v1/executives")
    public List<ExecutiveResDto> fetchExecutives( @RequestParam(name = "page", required = false, defaultValue = "0") Integer page,
                                                  @RequestParam(name = "size", required = false, defaultValue = "10") Integer size) {

        return executiveService.fetchExecutives(page, size);
    }

    @PutMapping("/api/v1/executive/{executiveId}/update")
    public ResponseEntity<ExecutiveResDto> updateExecutive(@PathVariable Long executiveId,
                                                           @Valid @RequestBody ExecutiveDto executiveDto,
                                                            Principal principal){
        return ResponseEntity.ok()
                .body(executiveService.updateExecutive( executiveId, principal.getName(),executiveDto));
    }
    @PutMapping("/api/v1/executive/{executiveId}/delete")
    public void deleteExecutive(@PathVariable Long  executiveId,
                                  Principal principal){
        executiveService.deleteExecutive( executiveId , principal.getName());

    }

}
