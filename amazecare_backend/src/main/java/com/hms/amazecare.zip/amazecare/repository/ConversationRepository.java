package com.hms.amazecare.repository;

import com.hms.amazecare.model.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


public interface ConversationRepository extends JpaRepository<Conversation, Long> {

    Optional<Conversation> findByPatientIdAndDoctorId(Long id, Long doctorId);
}
