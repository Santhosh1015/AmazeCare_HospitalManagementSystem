package com.hms.amazecare.repository;

import com.hms.amazecare.model.Patient;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

    Patient findByUserId(Long id);


    @Query("""
            select distinct a.patient
            from Appointment a
            where a.doctor.id = ?1
            """)
    List<Patient> fetchPatientsByDoctor(Long id, Pageable pageable);

    Optional<Patient> findByUserEmail(String patientEmail);
}
